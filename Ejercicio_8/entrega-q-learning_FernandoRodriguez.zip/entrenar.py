"""Entrena Q-learning en Cliff Walking 4x12 y guarda política, recompensas y gráfica.

Uso:  python entrenar.py            (semilla 42)
      python entrenar.py --semilla 7
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from cliff import (ACCIONES, INICIO, dibujar_politica, entrenar, evaluar_greedy, paso)

AQUI = Path(__file__).parent
SALIDA: list[str] = []


def imprime(texto: str = "") -> None:
    print(texto)
    SALIDA.append(texto)


def media_movil(serie: list[float], ventana: int = 10) -> list[float]:
    return [sum(serie[max(0, i - ventana + 1): i + 1]) / len(serie[max(0, i - ventana + 1): i + 1])
            for i in range(len(serie))]


def comprobar_entorno() -> None:
    assert paso(INICIO, "N") == ((2, 0), -1.0, False)       # norte desde S
    assert paso(INICIO, "E") == (INICIO, -100.0, False)     # este desde S: cae, vuelve a S, sigue
    assert paso((2, 11), "S") == ((3, 11), -1.0, True)      # sur desde (2,11): entra a G
    imprime("Comprobación manual del entorno: N desde S -> (2,0) r=-1 | E desde S -> S r=-100 (sigue) | "
            "S desde (2,11) -> G r=-1 (termina)  [OK]")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--semilla", type=int, default=42)
    args = ap.parse_args()

    alpha, epsilon, episodios, max_pasos = 0.5, 0.1, 500, 200
    imprime("CLIFF WALKING 4x12 — Q-learning tabular")
    imprime(f"alpha={alpha}  gamma=1  epsilon={epsilon}  episodios={episodios}  Q inicial=0  "
            f"tope={max_pasos} pasos  semilla={args.semilla}")
    imprime(f"Desempate fijo: {', '.join(ACCIONES)} (gana la primera)\n")
    comprobar_entorno()

    Q, retornos, cortados = entrenar(alpha, epsilon, episodios, max_pasos, args.semilla)
    camino, acciones, retorno, llego = evaluar_greedy(Q, max_pasos)

    imprime("\nPOLÍTICA GREEDY (epsilon = 0)  [* = casilla del camino recorrido desde S]")
    imprime(dibujar_politica(Q, camino))
    imprime("\nCamino S -> G: " + " ".join(f"({f},{c})" for f, c in camino))
    imprime("Acciones:      " + " ".join(acciones))
    imprime(f"Llegó a G: {llego} | pasos: {len(acciones)} | retorno greedy: {retorno:g}")
    imprime("Q(S, ·) = " + ", ".join(f"{a}: {Q[INICIO][a]:.2f}" for a in ACCIONES))

    mm = media_movil(retornos, 10)
    imprime("\nENTRENAMIENTO (epsilon-greedy encendida)")
    imprime(f"Episodios cortados por el tope de {max_pasos} pasos: {cortados}")
    imprime(f"Recompensa media, episodios 1-100:   {sum(retornos[:100]) / 100:8.2f}")
    imprime(f"Recompensa media, episodios 401-500: {sum(retornos[400:]) / 100:8.2f}")
    imprime(f"Mejor episodio: {max(retornos):g} | peor episodio: {min(retornos):g}")
    imprime(f"Episodios de entrenamiento con retorno -13 exacto: {sum(r == -13 for r in retornos)}")
    imprime(f"Episodios que cayeron al acantilado al menos una vez (retorno <= -100): "
            f"{sum(r <= -100 for r in retornos)}")

    with open(AQUI / "recompensas.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["episodio", "recompensa", "media_movil_10"])
        for i, (r, m) in enumerate(zip(retornos, mm), start=1):
            w.writerow([i, f"{r:g}", f"{m:.2f}"])

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 4.8))
    x = range(1, episodios + 1)
    ax.plot(x, retornos, color="#9ecae1", lw=0.8, label="recompensa por episodio")
    ax.plot(x, mm, color="#08519c", lw=2, label="media móvil (10 episodios)")
    ax.axhline(-13, color="#31a354", ls="--", lw=1.4, label="retorno greedy óptimo (−13)")
    ax.set_ylim(-200, 0)
    ax.set_xlabel("Episodios")
    ax.set_ylabel("Suma de recompensas en el episodio")
    ax.set_title(f"Q-learning en Cliff Walking (ε=0.1, α=0.5, semilla {args.semilla})")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(AQUI / "curva.png", dpi=150)

    (AQUI / "salida.txt").write_text("\n".join(SALIDA) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
