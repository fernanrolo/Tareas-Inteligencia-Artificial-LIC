"""Cliff Walking (Sutton y Barto) y Q-learning tabular. Implementación propia, solo librería estándar."""

from __future__ import annotations

import random

FILAS, COLUMNAS = 4, 12
INICIO = (3, 0)
META = (3, 11)
ACANTILADO = {(3, c) for c in range(1, 11)}      # (3,1) ... (3,10)

ACCIONES = ("N", "E", "S", "W")                  # orden fijo; también desempata los empates
MOVIMIENTO = {"N": (-1, 0), "E": (0, 1), "S": (1, 0), "W": (0, -1)}
FLECHA = {"N": "↑", "E": "→", "S": "↓", "W": "←"}

R_PASO, R_ACANTILADO = -1.0, -100.0
GAMMA = 1.0


# --------------------------------------------------------------------------- #
# Entorno
# --------------------------------------------------------------------------- #

def paso(estado: tuple[int, int], accion: str):
    """Devuelve (siguiente_estado, recompensa, terminal)."""
    f, c = estado
    df, dc = MOVIMIENTO[accion]
    nf, nc = f + df, c + dc
    if not (0 <= nf < FILAS and 0 <= nc < COLUMNAS):   # choca con el borde: se queda
        nf, nc = f, c
    if (nf, nc) in ACANTILADO:                          # cae: vuelve a S, el episodio SIGUE
        return INICIO, R_ACANTILADO, False
    if (nf, nc) == META:                                # entra a G: termina
        return META, R_PASO, True
    return (nf, nc), R_PASO, False


def estados_no_terminales():
    return [(f, c) for f in range(FILAS) for c in range(COLUMNAS)
            if (f, c) != META and (f, c) not in ACANTILADO]


# --------------------------------------------------------------------------- #
# Q-learning
# --------------------------------------------------------------------------- #

def tabla_q_vacia() -> dict[tuple[int, int], dict[str, float]]:
    return {s: {a: 0.0 for a in ACCIONES} for s in estados_no_terminales()}


def max_q(Q, estado) -> float:
    return max(Q[estado].values())


def accion_greedy(Q, estado) -> str:
    """Acción de mayor Q; en empates gana la primera de ACCIONES (N, E, S, W)."""
    mejor = ACCIONES[0]
    for a in ACCIONES[1:]:
        if Q[estado][a] > Q[estado][mejor]:
            mejor = a
    return mejor


def accion_epsilon_greedy(Q, estado, epsilon: float, rng: random.Random) -> str:
    if rng.random() < epsilon:
        return rng.choice(ACCIONES)
    return accion_greedy(Q, estado)


def entrenar(alpha=0.5, epsilon=0.1, episodios=500, max_pasos=200, semilla=0):
    """Q-learning off-policy. Devuelve (Q, recompensa_por_episodio, episodios_cortados_por_tope)."""
    rng = random.Random(semilla)
    Q = tabla_q_vacia()
    retornos: list[float] = []
    cortados = 0
    for _ in range(episodios):
        s, total, terminó = INICIO, 0.0, False
        for _t in range(max_pasos):
            a = accion_epsilon_greedy(Q, s, epsilon, rng)          # conducta
            s2, r, terminal = paso(s, a)
            futuro = 0.0 if terminal else max_q(Q, s2)             # objetivo: máximo en s'
            objetivo = r + GAMMA * futuro
            Q[s][a] += alpha * (objetivo - Q[s][a])
            total += r
            s = s2
            if terminal:
                terminó = True
                break
        if not terminó:
            cortados += 1
        retornos.append(total)
    return Q, retornos, cortados


def evaluar_greedy(Q, max_pasos=200):
    """Recorrido con epsilon = 0. Devuelve (camino, acciones, retorno, llegó_a_G)."""
    s = INICIO
    camino, acciones, retorno = [s], [], 0.0
    for _ in range(max_pasos):
        a = accion_greedy(Q, s)
        s, r, terminal = paso(s, a)
        camino.append(s)
        acciones.append(a)
        retorno += r
        if terminal:
            return camino, acciones, retorno, True
    return camino, acciones, retorno, False


def dibujar_politica(Q, camino=()) -> str:
    """Cuadrícula con la acción greedy de cada casilla; * marca el camino recorrido."""
    en_camino = set(camino)
    lineas = ["      " + " ".join(f"{c:>3}" for c in range(COLUMNAS))]
    for f in range(FILAS):
        celdas = []
        for c in range(COLUMNAS):
            if (f, c) == META:
                txt = " G "
            elif (f, c) in ACANTILADO:
                txt = " C "
            else:
                marca = "*" if (f, c) in en_camino else " "
                txt = f"{FLECHA[accion_greedy(Q, (f, c))]}{marca} "
                if (f, c) == INICIO:
                    txt = f"S{FLECHA[accion_greedy(Q, (f, c))]} "
            celdas.append(txt)
        lineas.append(f"fila {f} " + " ".join(celdas))
    return "\n".join(lineas)
