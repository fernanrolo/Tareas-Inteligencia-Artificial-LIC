"""Corre las tres consultas con ambos algoritmos y el experimento de Luis.

Uso:  python ejecutar.py                 (imprime y guarda trazas.txt)
"""

from __future__ import annotations

import sys
from pathlib import Path

from logica import (BaseConocimiento, cargar_base, encadenar_adelante,
                    encadenar_atras, parsear_atomo)

AQUI = Path(__file__).parent
SALIDA: list[str] = []


def imprime(texto: str = "") -> None:
    print(texto)
    SALIDA.append(texto)


def correr(kb: BaseConocimiento, consulta, titulo: str) -> None:
    imprime("=" * 72)
    imprime(titulo)
    imprime("=" * 72)

    fc = encadenar_adelante(kb, consulta)
    imprime(f"\n[HACIA ADELANTE]  {consulta}  ->  {'SÍ (probada)' if fc.probada else 'NO (no probada)'}")
    for linea in fc.traza:
        imprime("  " + linea)
    imprime(f"  Átomos nuevos (en orden): {', '.join(map(str, fc.atomos)) or '(ninguno)'}")

    bc = encadenar_atras(kb, consulta)
    imprime(f"\n[HACIA ATRÁS]  {consulta}  ->  {'SÍ (probada)' if bc.probada else 'NO (no probada)'}")
    for linea in bc.traza:
        imprime("  " + linea)
    imprime(f"  Metas visitadas: {', '.join(map(str, bc.atomos))}")
    imprime("  Hechos añadidos: ninguno (hacia atrás no deriva átomos)\n")


def main() -> None:
    kb = cargar_base(AQUI / "kb" / "biblioteca.yaml")

    imprime("BASE DE CONOCIMIENTO")
    for h in kb.hechos:
        imprime(f"  hecho  {h}")
    for r in kb.reglas:
        imprime(f"  regla  {r}")
    imprime()

    for i, q in enumerate(kb.consultas, start=1):
        correr(kb, q, f"CONSULTA {i}: {q}")

    # Experimento del reporte: añadir TieneCredencial(Luis) y volver a preguntar
    kb2 = kb.con_hecho(parsear_atomo("TieneCredencial(Luis)"))
    correr(kb2, parsear_atomo("AccesoNoche(Luis)"),
           "EXPERIMENTO: se añade el hecho TieneCredencial(Luis); consulta AccesoNoche(Luis)")

    (AQUI / "trazas.txt").write_text("\n".join(SALIDA) + "\n", encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
