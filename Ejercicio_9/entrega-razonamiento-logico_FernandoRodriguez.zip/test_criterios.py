"""Comprueba los criterios de aceptación del enunciado.  Uso: python test_criterios.py"""

from pathlib import Path

from logica import cargar_base, encadenar_adelante, encadenar_atras, parsear_atomo

kb = cargar_base(Path(__file__).parent / "kb" / "biblioteca.yaml")
A = parsear_atomo
ESPERADOS = ["Miembro(Ana)", "Miembro(Marta)", "Becario(Ana)", "AccesoNoche(Ana)", "AccesoNoche(Marta)"]

# ---- hacia adelante: mismos átomos nuevos y mismo orden en las tres consultas
for q, esperado in [("AccesoNoche(Ana)", True), ("AccesoNoche(Luis)", False), ("AccesoNoche(Marta)", True)]:
    r = encadenar_adelante(kb, A(q))
    assert [str(a) for a in r.atomos] == ESPERADOS, (q, r.atomos)
    assert r.probada is esperado, q
    texto = "\n".join(r.traza)
    if q == "AccesoNoche(Luis)":
        for prohibido in ("Miembro(Luis)", "Becario(Luis)", "AccesoNoche(Luis)"):
            assert prohibido not in [str(a) for a in r.atomos]
    assert texto.index("--- ronda 2") < texto.index("⇒ AccesoNoche(Ana)")  # R_acceso no dispara en la ronda 1
print("OK  hacia adelante: 5 átomos nuevos en el orden pedido; Ana y Marta sí, Luis no")

# ---- hacia atrás
ana = encadenar_atras(kb, A("AccesoNoche(Ana)"))
t = "\n".join(ana.traza)
assert ana.probada
for esperado in ("R_acceso", "R_miembro_est", "Estudiante(Ana)", "TieneCredencial(Ana)", "HorarioNocturno(Hoy)"):
    assert esperado in t, esperado
for ausente in ("Luis", "Marta", "R_beca", "Becario", "R_miembro_prof"):
    assert ausente not in t, ausente
print("OK  hacia atrás Ana: usa R_acceso y R_miembro_est; sin Luis, Marta, R_beca ni Becario")

marta = encadenar_atras(kb, A("AccesoNoche(Marta)"))
t = "\n".join(marta.traza)
assert marta.probada
assert t.index("R_miembro_est") < t.index("fallo  Estudiante(Marta)") < t.index("R_miembro_prof") < t.index("hecho  Profesor(Marta)")
print("OK  hacia atrás Marta: R_miembro_est falla (no hay Estudiante(Marta)) y R_miembro_prof prueba")

luis = encadenar_atras(kb, A("AccesoNoche(Luis)"))
t = "\n".join(luis.traza)
assert not luis.probada
assert "fallo  TieneCredencial(Luis)" in t and "fallo  Profesor(Luis)" in t
print("OK  hacia atrás Luis: falla (sin TieneCredencial(Luis) ni Profesor(Luis))")

# ---- experimento
kb2 = kb.con_hecho(A("TieneCredencial(Luis)"))
fc = encadenar_adelante(kb2, A("AccesoNoche(Luis)"))
assert fc.probada and encadenar_atras(kb2, A("AccesoNoche(Luis)")).probada
print("OK  con TieneCredencial(Luis): AccesoNoche(Luis) queda probada")
print("Todos los criterios se cumplen.")
