"""Inferencia con cláusulas definidas: encadenamiento hacia adelante y hacia atrás.

Implementación propia (sin depender del proyecto de referencia).
Convención: variable = empieza con minúscula (x); constante = mayúscula (Ana).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

# --------------------------------------------------------------------------- #
# Átomos, sustituciones y unificación
# --------------------------------------------------------------------------- #

_PATRON_ATOMO = re.compile(r"^\s*([A-Za-z_]\w*)\s*(?:\(\s*(.*?)\s*\))?\s*$")


@dataclass(frozen=True)
class Atomo:
    pred: str
    args: tuple[str, ...] = ()

    def __str__(self) -> str:
        return f"{self.pred}({', '.join(self.args)})" if self.args else self.pred


def parsear_atomo(texto: str) -> Atomo:
    m = _PATRON_ATOMO.match(texto)
    if not m:
        raise ValueError(f"No puedo leer el átomo: {texto!r}")
    pred, crudo = m.group(1), m.group(2)
    if not crudo:
        return Atomo(pred)
    return Atomo(pred, tuple(p.strip() for p in crudo.split(",")))


def es_variable(termino: str) -> bool:
    return termino[:1].islower()


def resolver(termino: str, sust: dict[str, str]) -> str:
    """Sigue la cadena de ligaduras de una variable hasta un valor final."""
    while es_variable(termino) and termino in sust:
        termino = sust[termino]
    return termino


def aplicar(atomo: Atomo, sust: dict[str, str]) -> Atomo:
    return Atomo(atomo.pred, tuple(resolver(t, sust) for t in atomo.args))


def unificar(a: Atomo, b: Atomo, sust: dict[str, str]) -> dict[str, str] | None:
    """Unifica dos átomos extendiendo `sust`. Devuelve una sustitución nueva o None."""
    if a.pred != b.pred or len(a.args) != len(b.args):
        return None
    sust = dict(sust)
    for t1, t2 in zip(a.args, b.args):
        t1, t2 = resolver(t1, sust), resolver(t2, sust)
        if t1 == t2:
            continue
        if es_variable(t1):
            sust[t1] = t2
        elif es_variable(t2):
            sust[t2] = t1
        else:  # dos constantes distintas
            return None
    return sust


# --------------------------------------------------------------------------- #
# Base de conocimiento
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Regla:
    id: str
    premisas: tuple[Atomo, ...]
    cabeza: Atomo

    def __str__(self) -> str:
        return f"{self.id}: {' ∧ '.join(map(str, self.premisas))} → {self.cabeza}"


@dataclass
class BaseConocimiento:
    hechos: list[Atomo]
    reglas: list[Regla]
    consultas: list[Atomo] = field(default_factory=list)

    def con_hecho(self, hecho: Atomo) -> "BaseConocimiento":
        """Copia de la base con un hecho más al final (no modifica la original)."""
        return BaseConocimiento(self.hechos + [hecho], list(self.reglas), list(self.consultas))


def cargar_base(ruta: str | Path) -> BaseConocimiento:
    with open(ruta, encoding="utf-8") as fh:
        crudo = yaml.safe_load(fh)
    hechos = [parsear_atomo(h) for h in crudo.get("facts", [])]
    reglas = [
        Regla(r["id"], tuple(parsear_atomo(p) for p in r["if"]), parsear_atomo(r["then"]))
        for r in crudo.get("rules", [])
    ]
    consultas = [parsear_atomo(q) for q in crudo.get("queries", [])]
    return BaseConocimiento(hechos, reglas, consultas)


def _renombrar(regla: Regla, n: int) -> Regla:
    """Variables nuevas por cada uso de la regla: x -> x_1, x_2, ..."""
    def ren(a: Atomo) -> Atomo:
        return Atomo(a.pred, tuple(f"{t}_{n}" if es_variable(t) else t for t in a.args))
    return Regla(regla.id, tuple(ren(p) for p in regla.premisas), ren(regla.cabeza))


def _sust_legible(sust: dict[str, str], regla: Regla) -> str:
    """Muestra x/Ana en vez de x_3/Ana: solo variables de la regla, ya resueltas."""
    vars_regla = sorted({t for a in (*regla.premisas, regla.cabeza) for t in a.args if es_variable(t)})
    partes = [f"{v.rsplit('_', 1)[0]}/{resolver(v, sust)}" for v in vars_regla]
    return "{" + ", ".join(partes) + "}"


@dataclass
class Resultado:
    probada: bool
    sustitucion: dict[str, str] | None
    traza: list[str]
    atomos: list[Atomo]  # adelante: átomos nuevos derivados; atrás: metas visitadas


# --------------------------------------------------------------------------- #
# Encadenamiento hacia adelante (dirigido por los datos)
# --------------------------------------------------------------------------- #

def _satisfacer(premisas: tuple[Atomo, ...], hechos: list[Atomo], sust: dict[str, str]):
    """Todas las sustituciones que satisfacen las premisas, en orden de premisas y hechos."""
    if not premisas:
        yield sust
        return
    meta = aplicar(premisas[0], sust)
    for hecho in hechos:
        theta = unificar(meta, hecho, sust)
        if theta is not None:
            yield from _satisfacer(premisas[1:], hechos, theta)


def encadenar_adelante(kb: BaseConocimiento, consulta: Atomo, max_rondas: int = 100) -> Resultado:
    hechos = list(kb.hechos)
    nuevos: list[Atomo] = []
    traza = [f"Hechos iniciales: {', '.join(map(str, hechos))}", f"Consulta: {consulta}"]
    usos = 0

    for ronda in range(1, max_rondas + 1):
        base_ronda = list(hechos)          # solo se ven los hechos al empezar la ronda
        producidos: list[Atomo] = []
        traza.append(f"--- ronda {ronda} ---")
        for regla in kb.reglas:
            usos += 1
            r = _renombrar(regla, usos)
            for theta in _satisfacer(r.premisas, base_ronda, {}):
                cabeza = aplicar(r.cabeza, theta)
                if cabeza in base_ronda or cabeza in producidos:
                    continue
                producidos.append(cabeza)
                traza.append(f"dispara {regla.id} {_sust_legible(theta, r)} ⇒ {cabeza}")
        if not producidos:
            traza.append("sin átomos nuevos: punto fijo")
            break
        hechos.extend(producidos)          # disponibles a partir de la ronda siguiente
        nuevos.extend(producidos)

    for hecho in hechos:                   # primera respuesta en el orden de los hechos
        theta = unificar(consulta, hecho, {})
        if theta is not None:
            traza.append(f"PROBADA: {consulta}")
            return Resultado(True, theta, traza, nuevos)
    traza.append(f"NO PROBADA: {consulta}")
    return Resultado(False, None, traza, nuevos)


# --------------------------------------------------------------------------- #
# Encadenamiento hacia atrás (dirigido por la meta)
# --------------------------------------------------------------------------- #

def encadenar_atras(kb: BaseConocimiento, consulta: Atomo, max_prof: int = 30) -> Resultado:
    traza = [f"Consulta: {consulta}"]
    metas_vistas: list[Atomo] = []
    usos = [0]

    def sangria(p: int) -> str:
        return "  " * p

    def probar_meta(meta: Atomo, sust: dict[str, str], prof: int, pila: tuple[str, ...]):
        meta = aplicar(meta, sust)
        clave = str(meta)
        if clave in pila:
            traza.append(f"{sangria(prof)}ciclo: {meta} ya está en la pila, se corta")
            return None
        if prof > max_prof:
            traza.append(f"{sangria(prof)}profundidad máxima en {meta}")
            return None

        traza.append(f"{sangria(prof)}meta   {meta}")
        if meta not in metas_vistas:
            metas_vistas.append(meta)

        for hecho in kb.hechos:                       # 1) primero los hechos
            theta = unificar(meta, hecho, sust)
            if theta is not None:
                traza.append(f"{sangria(prof)}hecho  {hecho}")
                return theta

        for regla in kb.reglas:                       # 2) después las reglas, en orden
            usos[0] += 1
            r = _renombrar(regla, usos[0])
            theta = unificar(meta, r.cabeza, sust)
            if theta is None:
                continue
            traza.append(f"{sangria(prof)}regla  {regla.id}  (cabeza {regla.cabeza} unifica con {meta})")
            resultado = probar_conjuncion(list(r.premisas), theta, prof + 1, pila + (clave,))
            if resultado is not None:
                return resultado                      # primera prueba que funciona

        traza.append(f"{sangria(prof)}fallo  {meta}")
        return None

    def probar_conjuncion(premisas: list[Atomo], sust: dict[str, str], prof: int, pila: tuple[str, ...]):
        for premisa in premisas:
            sust = probar_meta(premisa, sust, prof, pila)
            if sust is None:
                return None
        return sust

    resp = probar_meta(consulta, {}, 0, ())
    traza.append(f"PROBADA: {consulta}" if resp is not None else f"NO PROBADA: {consulta}")
    return Resultado(resp is not None, resp, traza, metas_vistas)
